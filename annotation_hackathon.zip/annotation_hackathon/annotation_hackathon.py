import xml.etree.ElementTree as ET
import os
import shutil
from os import walk
import argparse
import time

sets_all=[\
#('2012', 'aeroplane')]
('2012', 'aeroplane'), ('2007', 'aeroplane'),\
('2012', 'bicycle'), ('2007', 'bicycle'),\
('2012', 'bird'), ('2007', 'bird'),\
('2012', 'boat'), ('2007', 'boat'),\
('2012', 'bottle'), ('2007', 'bottle'),\
('2012', 'bus'), ('2007', 'bus'),\
('2012', 'car'), ('2007', 'car'),\
('2012', 'cat'), ('2007', 'cat'),\
('2012', 'chair'),('2007', 'chair'),\
('2012', 'cow'), ('2007', 'cow'),\
('2012', 'diningtable'), ('2007', 'diningtable'),\
('2012', 'dog'), ('2007', 'dog'),\
('2012', 'horse'), ('2007', 'horse'),\
('2012', 'motorbike'), ('2007', 'motorbike'),\
('2012', 'person'), ('2007', 'person'),\
('2012', 'pottedplant'), ('2007','pottedplant'),\
('2012', 'sheep'), ('2007', 'sheep'),\
('2012', 'sofa'), ('2007', 'sofa'),\
('2012', 'train'), ('2007', 'train'),\
('2012', 'tvmonitor'), ('2007', 'tvmonitor'),\
]



training_classes = [\
'aeroplane',\
'bicycle',\
'bird',\
'boat',\
'bottle',\
'bus',\
'car',\
'cat',\
'chair',\
'cow',\
'diningtable',\
'dog',\
'horse',\
'motorbike',\
'person',\
'pottedplant',\
'sheep',\
'sofa',\
'train',\
'tvmonitor',\
]

coco_classes = [\
'person',\
'bicycle',\
'car',\
'motorbike',\
'aeroplane',\
'bus',\
'train',\
'truck',\
'boat',\
'traffic light',\
'fire hydrant',\
'stop sign',\
'parking meter',\
'bench',\
'bird',\
'cat',\
'dog',\
'horse',\
'sheep',\
'cow',\
'elephant',\
'bear',\
'zebra',\
'giraffe',\
'backpack',\
'umbrella',\
'handbag',\
'tie',\
'suitcase',\
'frisbee',\
'skis',\
'snowboard',\
'sports ball',\
'kite',\
'baseball bat',\
'baseball glove',\
'skateboard',\
'surfboard',\
'tennis racket',\
'bottle',\
'wine glass',\
'cup',\
'fork',\
'knife',\
'spoon',\
'bowl',\
'banana',\
'apple',\
'sandwich',\
'orange',\
'broccoli',\
'carrot',\
'hot dog',\
'pizza',\
'donut',\
'cake',\
'chair',\
'sofa',\
'pottedplant',\
'bed',\
'diningtable',\
'toilet',\
'tvmonitor',\
'laptop',\
'mouse',\
'remote',\
'keyboard',\
'cell phone',\
'microwave',\
'oven',\
'toaster',\
'sink',\
'refrigerator',\
'book',\
'clock',\
'vase',\
'scissors',\
'teddy bear',\
'hair drier',\
'toothbrush',\
]

path_training_data = '../VOCdevkit'
path_dataset = '../image_dataset'
path_training_info_save_to = 'training_info'
folder_image_class = 'image_class'
path_image_class = path_dataset + '/%s'%(folder_image_class)
gdrive_image_direction = '/gdrive/My Drive/hackathon2020/image_dataset/image_class/'

def convert_annotation(image_id, list_file, class_name):
    #in_file = open('/mnt/sdd/craig/voc/VOCdevkit/VOC%s/Annotations/%s.xml'%(year, image_id))
    in_file = open(path_dataset + '/Annotations_XML/%s.xml'%(image_id))
    tree=ET.parse(in_file)
    root = tree.getroot()
    for obj in root.iter('object'):
        difficult = obj.find('difficult').text
        cls = obj.find('name').text
        if class_name is not None :
            if cls != class_name:
                continue

        if cls not in training_classes or int(difficult)==1:
            continue
        cls_id = coco_classes.index(cls)
        xmlbox = obj.find('bndbox')
        b = (int(xmlbox.find('xmin').text), int(xmlbox.find('ymin').text), int(xmlbox.find('xmax').text), int(xmlbox.find('ymax').text))
        list_file.write(" " + ",".join([str(a) for a in b]) + ',' + str(cls_id))

def _gen_train(sets):
    if os.path.exists(path_training_info_save_to):
        shutil.rmtree(path_training_info_save_to)
    time.sleep(1)
    os.mkdir(path_training_info_save_to)
    #for class_idx in training_classes:
    # print("class:",class_idx)
        #===============================
    for class_name in sets:
        image_set = class_name + '_trainval'
        image_ids = open(path_dataset+'/ImageSets/%s.txt'%(image_set)).read().strip().split()
        # print("image_ids",image_ids)
        index = len(image_ids)
        while index > 0:
            if image_ids[index-1] == '-1' or image_ids[index-1] == '0':
                image_ids.pop(index-1)
                image_ids.pop(index-2)
            elif image_ids[index-1] == '1':
                image_ids.pop(index-1)
            index -=2
        # print("image_ids",image_ids)

        list_file = open(path_training_info_save_to + '/%s.txt'%(image_set), 'a')

        class_folder = path_image_class + '/%s'%(image_set)

        for image_id in image_ids:
            path_image_new = class_folder + '/%s.jpg'%(image_id)
            gdrive_image_path = gdrive_image_direction + '%s'%(image_set) + '/%s.jpg'%(image_id)
            if os.path.isfile(path_image_new):
                #list_file.write(path_image_new)
                list_file.write(gdrive_image_path)
                convert_annotation(image_id, list_file, None)
                list_file.write('\n')

        list_file.close()
    print('Done')

def _main():
    parser = argparse.ArgumentParser(description="convert annotation")
    parser.add_argument('-t', '--train', nargs='+', help='Select Training class and generate train annatation file')
    parser.add_argument('-v', '--validation',action='store_true', help='generate validation annatation file')
    parser.add_argument('-c', '--classify', action='store_true', help='image data classify')

    # parser.add_argument('-m', '--merge', action='store_true', help='merge')
    args = parser.parse_args()
    sets = []
    cnt = 0

    if args.train is not None:
        for class_name in args.train :
            if class_name.isnumeric() :
                if int(args.train[cnt]) < len(training_classes) :
                    args.train[cnt] = training_classes[int(args.train[cnt])]
                else :
                    print('invalid class index %s\n'%(int(args.train[cnt])))
                    return
            else :
                if args.train[cnt] not in training_classes :
                    print('invalid class name %s\n'%(args.train[cnt]))
                    return

            cnt = cnt + 1
        print('class select',args.train)


        for class_name in args.train :
            sets.append(class_name)
        _gen_train(sets)

if __name__ == '__main__':

    _main()


